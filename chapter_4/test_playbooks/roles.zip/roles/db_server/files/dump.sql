CREATE TABLE IF NOT EXISTS test (
  message varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO test(message) VALUES('Ansible To Do List');
INSERT INTO test(message) VALUES('Get ready');
INSERT INTO test(message) VALUES('Ansible is fun')
